import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import tkinter as tk
from tkinter import ttk

# --- Data ---
data = {
    'type': ['movie', 'movie', 'book', 'book', 'product', 'product'],
    'title': [
        'KGF', 'Bhabubali',
        'The Hobbit', 'Harry Potter',
        'iPhone 14', 'Samsung Galaxy S22',
    ],
    'description': [
        'A thief enters dreams to plant ideas.',
        'A hacker discovers reality is a simulation.',
        'A hobbit goes on a journey with dwarves.',
        'A boy discovers he is a wizard.',
        'Apple smartphone with A15 Bionic chip.',
        'Samsung smartphone with powerful camera and performance.'
    ]
}
df = pd.DataFrame(data)

# --- TF-IDF + Cosine Similarity ---
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(df['description'])
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)
indices = pd.Series(df.index, index=df['title']).drop_duplicates()

# --- Recommendation Logic ---
def recommend(title, item_type, n=3):
    if title not in indices:
        return ['Item not found.']
    idx = indices[title]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:n+1]
    recommendations = []
    for i, _ in sim_scores:
        if df.loc[i, 'type'] == item_type:
            recommendations.append(df.loc[i, 'title'])
    return recommendations if recommendations else ['No similar items found.']

# --- GUI Setup ---
root = tk.Tk()
root.title("Recommendation System")
root.geometry("500x300")

# --- UI Elements ---
category_label = tk.Label(root, text="Select Category:")
category_label.pack()

category_var = tk.StringVar()
category_menu = ttk.Combobox(root, textvariable=category_var, state='readonly')
category_menu['values'] = ['movie', 'book', 'product']
category_menu.pack()

item_label = tk.Label(root, text="Select Item:")
item_label.pack()

item_var = tk.StringVar()
item_menu = ttk.Combobox(root, textvariable=item_var, state='readonly')
item_menu.pack()

# Update items based on selected category
def update_items(event=None):
    selected_cat = category_var.get()
    filtered_titles = df[df['type'] == selected_cat]['title'].tolist()
    item_menu['values'] = filtered_titles
    if filtered_titles:
        item_menu.current(0)

category_menu.bind("<<ComboboxSelected>>", update_items)

# Results area
result_label = tk.Label(root, text="Recommendations:")
result_label.pack()

result_text = tk.Text(root, height=5, width=60)
result_text.pack()

# Recommendation function for GUI
def show_recommendations():
    selected_title = item_var.get()
    selected_cat = category_var.get()
    results = recommend(selected_title, selected_cat)
    result_text.delete(1.0, tk.END)
    result_text.insert(tk.END, "\n".join(results))

recommend_btn = tk.Button(root, text="Get Recommendations", command=show_recommendations)
recommend_btn.pack(pady=10)

root.mainloop()
